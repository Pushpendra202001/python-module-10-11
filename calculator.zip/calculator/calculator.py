# ASSIGNMENT 1:
# Module 10 & 11: CALCULATOR USING TKINTER
from tkinter import *
import re
from unicodedata import decimal

window = Tk()
num1=num2=operator=''
def addNumber(num):
    global num1, num2, operator
    val = e1.get()
    e1.delete(0, END)
    if operator=='':
        num1 = val + str(num)
        e1.insert(0, num1)
    else:
        num2 = val + str(num)
        e1.insert(0, num2)


def delNumber():
    e1.delete(0, END)

def operatorFun(op):
    global num1, operator

    if op == '+' or op == '-' or op == '*' or op == '/':
        operator = str(op)
        val = e1.get()
        label_value = label1.cget("text")
        if val!='':
            if label_value=='':
                e1.delete(0, END)
                label1.config(text=val+op)
            else:
                label1.config(text=str(label_value)+op)
        else:
            label_value = label1.cget("text")
            label1.config(text= str(label_value) + str(operator))


def calculate():
    global num1, num2, operator
    if num1!='' and num2!='':
        if operator == '+':
            result = int(num1) + int(num2)
            label1.config(text=result)
            num1 = str(result)
        elif operator == '*':
            result = int(num1) * int(num2)
            label1.config(text=result)
            num1 = str(result)

        elif operator == '-':
            result = int(num1) - int(num2)
            label1.config(text=result)
            num1 = str(result)

        elif operator == '/':
            if int(num2)>0 :
                result = int(num1) / int(num2)
                label1.config(text=str(result))
                num1 = str(result)
            else:
                label1.config(text='not devided by 0')
    else:
        label1.config(text='insert number and second')
    e1.delete(0, END)


def clrScr():
    global num1, num2, operator
    e1.delete(0, END)
    label1.config(text='')
    num1 = num2= operator=''

window.title("Calculator")
window.geometry("285x480")
window.configure(background = "black")
label1 = Label(window, text="", bg="grey", fg="white", font=("Arial", 16), anchor="w")
label1.place(x=0, y=0, width=400, height=50)
e1 = Entry(window, width = 280, font=('Arial', 25),   bg = "white", fg = "black", borderwidth=2, relief="ridge")
e1.place(x = 0, y = 50, width = 400, height = 50)
btn1 = Button(window, text = "1", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber(1))
btn1.place(x = 5, y = 105)
btn2 = Button(window, text = "2", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber(2))
btn2.place(x = 75, y = 105)
btn3 = Button(window, text = "3", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber(3))
btn3.place(x = 145, y = 105)
btnAdd = Button(window, text = "+", bg = "green", fg = "white", width=8, height=4, command=lambda :operatorFun("+"))
btnAdd.place(x = 215, y = 105)
btn4 = Button(window, text = "4", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber("4"))
btn4.place(x = 5, y = 180)
btn5 = Button(window, text = "5", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber("5"))
btn5.place(x = 75, y = 180)
btn6 = Button(window, text = "6", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber("6"))
btn6.place(x = 145, y = 180)
btnSub = Button(window, text = "-", bg = "green", fg = "white", width=8, height=4, command=lambda :operatorFun("-"))
btnSub.place(x = 215, y = 180)
btn7 = Button(window, text = "7", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber("7"))
btn7.place(x = 5, y = 255)
btn8 = Button(window, text = "8", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber("8"))
btn8.place(x = 75, y = 255)
btn9 = Button(window, text = "9", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber("9"))
btn9.place(x = 145, y = 255)
btnMul = Button(window, text = "*", bg = "green", fg = "white", width=8, height=4, command=lambda :operatorFun("*"))
btnMul.place(x = 215, y = 255)
btn0 = Button(window, text = "0", bg = "green", fg = "white", width=8, height=4, command=lambda :addNumber("0"))
btn0.place(x = 5, y = 330)
btnX = Button(window, text = "X", bg = "green", fg = "white", width=8, height=4, command=lambda :delNumber())
btnX.place(x = 75, y = 330)
btnTotal= Button(window, text = "=", bg = "green", fg = "white", width=8, height=4, command=lambda :calculate())
btnTotal.place(x = 145, y = 330)
btnDiv= Button(window, text = "/", bg = "green", fg = "white", width=8, height=4, command=lambda :operatorFun("/"))
btnDiv.place(x = 215, y = 330)
btnCls = Button(window, text = "Clear Screen", bg = "green", fg = "white", width=38, height=4, command=lambda :clrScr())
btnCls.place(x = 5, y = 405)
mainloop()
